HORRORSTACK ANDROID MEDIA3 BUILD
================================
This project wraps the supplied HorrorStack TV v0.4.1 HTML without redesigning it.

Playback change:
- The existing HorrorStack UI stays in the WebView.
- When a channel/movie is played inside the Android app, JavaScript calls
  HorrorStackAndroid.play(url, title).
- PlayerActivity opens Media3/ExoPlayer and plays the URL natively.
- HTTP cleartext is enabled because the supplied HorrorStack playlists include HTTP feeds.
- HLS support is included through Media3's HLS module.
- Outside the Android wrapper, the original web/HLS.js playback code remains available.

Open this folder in Android Studio, allow Gradle sync, then build/install the app.
